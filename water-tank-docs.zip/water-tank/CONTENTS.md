# Water Tank — Project Documents

A side-on water simulation toy: a tank of water on a slow tilt, generating waves
you watch. Inspired by a powered see-saw water sculpture. No game, no hook — it's
a toy you set running and watch.

## Where to start

Read in this order:

1. **`docs/01-overview.md`** — what this is, the philosophy, what it is *not*.
2. **`docs/02-phase1-spec.md`** — the thing to build now. Side-on tank. This is
   the actual build target for Claude Code.
3. **`docs/03-architecture.md`** — the sim/render split. The one non-negotiable
   rule. Read before writing any code.
4. **`docs/04-phase2-isometric.md`** — the *future* upgrade. Do NOT build now.
   Documented so Phase 1 is built without foreclosing it.
5. **`docs/05-stack-and-decisions.md`** — why Rust + Macroquad + CPU, and the
   decisions already settled (so they're not re-litigated).

## TL;DR for Claude Code

Build **Phase 1 only** (`docs/02-phase1-spec.md`). Rust + Macroquad, CPU sim,
native build. Side-on 1D shallow-water in a tank, auto see-saw tilt plus a manual
slider, drawn as a filled surface profile. Obey the sim/render split in
`docs/03-architecture.md` — it's what keeps Phase 2 cheap. Ignore Phase 2 for now.
