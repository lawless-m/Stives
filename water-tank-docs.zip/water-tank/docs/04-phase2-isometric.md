# 04 — Phase 2: Isometric (DO NOT BUILD YET)

Documented so Phase 1 is built without foreclosing this. **Not a build target
now.** Only attempt after Phase 1 is done and genuinely pleasant to watch.

## What changes

1. **Sim: 1D strip → 2D grid.** Each cell gains a second horizontal velocity
   component; shallow-water now propagates in two directions. Waves can reflect
   off four walls and interfere — richer to watch. The see-saw can tilt
   corner-to-corner, or even precess (tilt direction slowly rotating) so waves
   chase around the tank.
2. **Render: a new, separate isometric renderer** alongside the side-on one. The
   sim does not change to accommodate it (that's the whole point of the split).

## Render approach — start cheap

The isometric render is where the spatial/visual-taste risk lives. Avoid it by
**not attempting realistic lighting first.**

- **First version (the cheap dodge):** draw the height grid as coloured
  isometric tiles/diamonds. Show height via **colour** (deep = dark blue, crests
  = light) and optionally a small vertical pixel offset. Let the **motion** sell
  it as water. Pure 2D Macroquad — no 3D camera, no surface normals, no lighting.
  This sidesteps the taste tax the same way the side-on profile does.
- Only after that works and reads well should anything fancier (true 3D mesh,
  shading) even be considered. Probably never needed for a hypnotic toy.

## Does it need the GPU?

No — not for a modest grid.

- **Sim:** CPU is fine up to roughly 256×256 cells at 60fps in Rust. Only a much
  larger grid would push the CPU.
- **Render:** Macroquad draws the iso tiles (or a 3D mesh) fine. No GPU compute
  needed for drawing.
- **The only thing that forces the GPU** is wanting a grid big enough that CPU
  simulation can't hold 60fps. That's the *single* trigger to consider wgpu
  compute — and it's a deliberate "I want bigger/faster water" ambition, not a
  requirement of going isometric. Don't pursue it speculatively. See
  `05-stack-and-decisions.md`.

## Order of attack, if/when Phase 2 happens

1. Widen sim to 2D grid; verify with the *existing* side-on renderer if helpful
   (e.g. draw one row), confirming the split held.
2. Add the cheap iso renderer (coloured tiles, height-as-colour, motion sells it).
3. Stop there unless genuinely unsatisfied.
