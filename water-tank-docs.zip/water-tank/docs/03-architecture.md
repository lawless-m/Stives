# 03 — Architecture (READ BEFORE CODING)

There is exactly **one** non-negotiable rule, and it exists to make Phase 2
(isometric) an additive change rather than a rewrite.

## The rule

> **The simulation knows nothing about how it is drawn.**
>
> The simulation owns the grid of state and steps the physics. The renderer is a
> separate module that reads that state **read-only** and draws it. They never
> touch each other's internals.

## Concretely

- **Sim module:** owns the cell array (height, velocity), steps physics given a
  tilt input, exposes the state for reading. Knows nothing about Macroquad,
  pixels, colours, screen coordinates, side-on vs isometric.
- **Render module:** takes a read-only view of sim state and draws it with
  Macroquad. Knows nothing about the physics.
- **Input/tilt:** feeds a tilt value into the sim. Isolated from both — so adding
  tilt momentum later, or a different input, touches only this layer.
- **Main loop:** wires them together — read input → step sim → render.

## Why this matters

Phase 2 (isometric) is then two contained, independent changes:
1. Widen the sim state from a 1D strip to a 2D grid (same equations, second
   velocity component). The render module is untouched by this.
2. Add a **new, separate** isometric renderer alongside the side-on one. The sim
   is untouched by this.

If sim and render bleed together, the iso upgrade becomes a teardown — this is
the exact failure mode that killed a previous Godot attempt. Keep the boundary
clean and working code is never threatened by the upgrade.

## Practical guidance

- Prefer a flat array + simple accessors for sim state over anything clever.
- The render module should be able to draw *any* valid sim state without
  assuming how it was produced.
- Don't optimise prematurely. CPU + clean structure first. (See
  `05-stack-and-decisions.md` for when, if ever, to reach for the GPU.)
