# 05 — Stack & Settled Decisions

Decisions already made and the reasoning, so they aren't re-litigated mid-build.

## Rust + Macroquad

- **Rust:** the preferred language for this work.
- **Macroquad:** minimal ceremony — a window and an immediate-mode draw API. Right
  fit for a single-purpose toy. Gets to sloshing water fast, keeps the sim/render
  split easy to see. Exports to WASM later if sharing is wanted, so "send people
  the tank" survives without committing to it now.

## CPU simulation, not GPU

- A 1D side-on strip (Phase 1) is trivial on CPU — Rust over a flat array is
  exactly the right tool.
- A modest 2D grid (Phase 2 iso, ≤~256×256) is also fine on CPU at 60fps.
- **The GPU is only earned by one specific ambition:** a grid big enough that CPU
  sim can't hold framerate. That, and only that, is the trigger to consider wgpu
  compute shaders. Not needed for the toy as specified.

## WebGPU / wgpu — explicitly NOT in scope

This was considered and dropped on purpose. It was briefly attractive as (a) work
prep and (b) a "proper" stack, but:
- The work angle (tabular sales-data classification) doesn't use GPU compute
  anyway — that's gradient-boosted-tree / CPU territory.
- WebGPU was never independently wanted; nothing is lost by skipping it.

If GPU-accelerated *simulation* ever becomes a real, felt need (big-grid water, or
a genuine separate interest in compute/neural-nets), the water makes an excellent
gentle on-ramp to wgpu compute — build the solver on CPU first as a correctness
reference, then port to a compute shader. But that's a future, optional curriculum
triggered by real need, never built speculatively.

## Manual tilt: slider, instantaneous

- **Slider, absolute, instantaneous** — no tilt momentum/inertia in Phase 1.
- Chosen for the set-and-let-run feel: set an angle, leave it, watch. The
  "grab-and-tip with momentum" variant (a second little physics system on the
  tilt itself) was considered and deferred — it's isolated to the input layer, so
  it can be added later without disturbing sim or render if the tankish feel is
  ever wanted.

## Scope discipline

The recurring failure mode to avoid: bolting a "point" (game, hook, goal) onto
what is fundamentally a toy. Resist it. The toy is complete without one. Build
Phase 1, watch it, and let *that* decide whether Phase 2 — or anything beyond — is
worth doing.
