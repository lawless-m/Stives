# 01 — Overview

## What this is

A **toy**, not a game. A tank of water, seen side-on, on a slow tilt. The tilt
makes the water slosh to the low end; waves propagate and reflect off the tank
walls. You set it running and watch it. That's the whole thing.

Reference point: a powered see-saw water sculpture — a tank on a slowly tipping
platform that generates standing waves. The goal is to recreate that hypnotic
set-and-watch quality.

## What it is NOT

- **Not a game.** No goal, no win state, no player objective, no score. Do not
  add one. The absence of a "point" is intentional — watching is the point.
- **Not photoreal.** No attempt at realistic lighting, caustics, or spray.
  Side-on water reads as water from a simple filled profile; that's enough.
- **Not GPU-bound.** Phase 1 runs on CPU. The 4070 is not needed and should not
  be invoked. (See `05-stack-and-decisions.md`.)

## Two modes of motion

1. **Auto (see-saw):** the tank tilts back and forth on a slow sine oscillation,
   on its own, like the powered original. This is the default — set it down and
   watch.
2. **Manual (slider):** a slider sets the tilt angle directly and absolutely.
   Set-and-let-run: pick an angle, leave it, watch the water find equilibrium and
   slosh on the way. Instantaneous (no tilt inertia in Phase 1).

## Success criterion

If you set it running and find it pleasant to watch — water sloshing believably,
waves bouncing off the walls, settling realistically — it's done. There is no
other bar to clear.
