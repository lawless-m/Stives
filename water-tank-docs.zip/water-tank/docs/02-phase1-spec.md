# 02 — Phase 1 Spec (BUILD THIS)

The complete, settled spec for the thing to build now. Side-on tank only.

## Stack

- **Language:** Rust
- **Framework:** Macroquad
- **Simulation:** CPU
- **Build target:** native first. WASM export is available from Macroquad later
  if sharing is wanted, but is not a Phase 1 requirement — don't add toolchain
  friction for it now.

## Simulation model

**1D shallow-water.** Side-on means the water surface is effectively a 1D profile
across the width of the tank.

- A flat array of cells across the tank width.
- Each cell holds at least: **water column height** and **horizontal velocity**.
- Step the shallow-water equations each frame: water flows from high columns to
  low, driven by the horizontal component of gravity (set by the tilt).
- **Reflecting walls** at both ends — waves bounce, they don't leak or wrap.
- Conserve water volume (no net gain/loss over time aside from intended physics).

Stability matters more than physical accuracy. Pick timestep / damping so it
stays stable at 60fps and *looks* like sloshing water. A small amount of damping
to let it settle is fine and desirable (the original settles between tilts).

## Tilt (the driver)

Tilt sets the direction of gravity relative to the tank, which drives the slosh.

- **Auto see-saw (default):** tilt angle follows a slow sine oscillation. Slow —
  this is meant to be hypnotic, not frantic. Make the period and max angle easy
  to find and tweak as constants.
- **Manual slider:** a UI slider sets the tilt angle directly and absolutely.
  Instantaneous — no tilt momentum/inertia in Phase 1. Set-and-let-run.
- A way to switch between auto and manual (e.g. the slider takes over when
  touched, or a simple toggle). Keep it obvious.

## Rendering

- **Filled surface profile.** Draw the water as a filled region: water below the
  surface line, air/empty above, within the tank rectangle.
- Draw the tank walls/floor so the container is visible.
- **No lighting, no shading, no normals.** A flat fill colour for water is enough;
  a profile line reads as water on its own.
- The renderer **only reads** simulation state. See `03-architecture.md`.

## Controls / UI (minimal)

- The tilt slider (manual mode).
- Auto/manual toggle (or implicit via slider interaction).
- Optional, nice-to-have: a reset/calm button. Not required.

Keep UI minimal — Macroquad's immediate-mode drawing is fine; no need for a UI
framework.

## Tunables to expose as named constants

So they're easy to find and play with:
- Number of cells (tank resolution)
- Auto-tilt period and max angle
- Gravity strength
- Damping factor
- Timestep / substeps per frame

## Done when

It runs, the water sloshes believably on auto-tilt, the slider tips it and it
settles, waves reflect off the walls, and it's pleasant to watch at 60fps.
